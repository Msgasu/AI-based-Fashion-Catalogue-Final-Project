import streamlit as st
import os
from PIL import Image
import numpy as np
import joblib
from tensorflow.keras.applications.vgg16 import VGG16, preprocess_input

# Loading the pre-trained models
kmeans_model = joblib.load('kmeans_model.joblib')
pca_model = joblib.load('pca_model.joblib')

# Loading the pre-trained VGG16 model
target_width = 120
target_height = 120
vgg16_model = VGG16(weights='imagenet', include_top=False, input_shape=(target_width, target_height, 3))

st.set_page_config(page_title='Automatic Image Catalogue', page_icon='👗')

# Function to process uploaded image and predict cluster
def process_image(image, target_width, target_height):
    img = Image.open(image).convert('RGB')
    img = img.resize((target_width, target_height))
    img_array = np.expand_dims(np.array(img), axis=0)
    return img_array

def extract_features(img_array):
    img_array_vgg16 = preprocess_input(img_array)
    features = vgg16_model.predict(img_array_vgg16)
    features_flattened = features.reshape(1, -1)
    return features_flattened

# Function to display images from a folder using PIL Image
def display_images(folder_path):
    images = os.listdir(folder_path)
    for img in images[:3]:
        image_path = os.path.join(folder_path, img)
        pil_image = Image.open(image_path)
        st.image(pil_image, width=120, use_column_width=False)


st.title(':gray[Fashion Categorizer]👗👠')

# CSS style 
css = f"""
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Lobster&family=Pacifico:wght@400&display=swap');

        body {{
            font-family: 'Pacifico';
            background: url('https://images.pexels.com/photos/167686/pexels-photo-167686.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940') no-repeat center center fixed;
            -webkit-background-size: cover;
            -moz-background-size: cover;
            -o-background-size: cover;
            background-size: cover;
            margin: 0;
            color: #333;
        }}

        .container {{
            max-width: 1000px;
            padding: 2rem;
            box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
            transition: 0.3s;
            border-radius: 5px;
            overflow: hidden;
        }}

        .container:hover {{
            box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
        }}

        h1 {{
            text-align: center;
            background-color: #fffff;
        }}

        .stApp {{
            max-width: 900px;
            margin: auto;
            background-color:#fffff ;
            padding: 2rem; 
            border-radius: 20px; 
        }}

        .sttitle {{
            text-align: center;
            font-family: 'Lobster', cursive;
            color: #ffffff;
            margin-bottom: 2rem;
            padding: 0.5rem;
            text-align: center;
            border-radius: 15% / 5%;
        }}

        .stHeader {{
            font-family: 'Pacifico', cursive;
            background-color: #f3e5ab;
            color: #333; 
            padding: 0.5rem;
            margin-top: 0.5rem;
            text-align: center; 
            border-radius: 15% / 5%; 
        }}

        .stColumnWrapper {{
            border: 2px solid #b2b2b2; 
            border-radius: 10px;
            margin-bottom: 2rem;
        }}

        .stColumn {{
            padding: 1rem;
            background-color: rgba(255, 255, 255, 0.8);
        }}

        .stUploadContainer {{
            margin-top: 2rem;
        }}

    </style>
"""

st.markdown(css, unsafe_allow_html=True)

# welcome message
st.markdown("<h1 class='sttitle'>Welcome to the Automatic Image Catalogue! 🚀</h1>", unsafe_allow_html=True)

# Divider
st.markdown("---")

# Asking the user for their choice
user_choice = st.radio("What would you like to do?", ("Upload an Image", "View Catalog"))

# placeholders for bags, shoes, and shirts
col1, col2, col3 = st.columns(3)

if user_choice == "Upload an Image":

    # Uploading image for prediction
    uploaded_file = st.file_uploader("Choose an image...", type=["jpg", "jpeg", "png"], key="fileUploader")

    # Adding Exit button
    if st.button("Exit"):
        st.warning("Exiting the application. Thanks for using the Automatic Image Catalogue! 🚀")
        st.balloons()  # Displayig balloons before exiting
        st.stop()  # Stoping the Streamlit app

    if uploaded_file is not None:
        # Processing the uploaded image
        img_array = process_image(uploaded_file, target_width, target_height)

        # Extracting features using VGG16
        features_flattened = extract_features(img_array)

        # Applying PCA to the features
        features_pca = pca_model.transform(features_flattened)

        # Predicting the cluster using KMeans model
        cluster_prediction = kmeans_model.predict(features_pca)[0]

        st.write(f"Predicted Cluster: {cluster_prediction}")

        # Moving the uploaded image to its respective folder
        if cluster_prediction == 0:
            destination_folder = 'C:\\Users\\USER\\Desktop\\AI final Project\\Clustering Deployment\\Shirts'
            col_to_update = col3
        elif cluster_prediction == 1:
            destination_folder = 'C:\\Users\\USER\\Desktop\\AI final Project\\Clustering Deployment\\Bags'
            col_to_update = col1
        elif cluster_prediction == 2:
            destination_folder = 'C:\\Users\\USER\\Desktop\\AI final Project\\Clustering Deployment\\Shoes'
            col_to_update = col2
        else:
            st.error("Invalid cluster prediction")

        # Saving the uploaded file with a predefined name in the destination folder
        filename = f"uploaded_image_{cluster_prediction}.png"
        file_path = os.path.join(destination_folder, filename)
        with open(file_path, "wb") as f:
            f.write(uploaded_file.getvalue())

        st.success("Image saved to the respective folder.")

        st.markdown("## Image Catalog")
        st.markdown("Here is the updated image catalog:")

        with col1:
            st.markdown("<h3 class='stHeader'>Bags</h3>", unsafe_allow_html=True)
          
            display_images('C:\\Users\\USER\\Desktop\\AI final Project\\Clustering Deployment\\Bags')

    # Divider
        st.markdown("---")
        with col2:
            st.markdown("<h3 class='stHeader'>Shoes</h3>", unsafe_allow_html=True)
          
            display_images('C:\\Users\\USER\\Desktop\\AI final Project\\Clustering Deployment\\Shoes')

        with col3:
            st.markdown("<h3 class='stHeader'>Apparel</h3>", unsafe_allow_html=True)
            
            display_images('C:\\Users\\USER\\Desktop\\AI final Project\\Clustering Deployment\\Shirts')

        # Dynamically updating the UI to show the moved image
        pil_image = Image.open(file_path)
        col_to_update.image(pil_image, caption=filename, width=100, use_column_width=False)
        st.success("Image moved to the respective column.")

        # Displaying the uploaded image in the UI
        st.image(pil_image, caption="Uploaded Image", width=100, use_column_width=False)


else:
    col1, col2, col3 = st.columns(3)

    with col1:
        st.markdown("<h3 class='stHeader'>Bags</h3>", unsafe_allow_html=True)
        
        display_images('C:\\Users\\USER\\Desktop\\AI final Project\\Clustering Deployment\\Bags')

    with col2:
        st.markdown("<h3 class='stHeader'>Shoes</h3>", unsafe_allow_html=True)
        
        display_images('C:\\Users\\USER\\Desktop\\AI final Project\\Clustering Deployment\\Shoes')

    with col3:
        st.markdown("<h3 class='stHeader'>Apparel</h3>", unsafe_allow_html=True)
       
        display_images('C:\\Users\\USER\\Desktop\\AI final Project\\Clustering Deployment\\Shirts')
